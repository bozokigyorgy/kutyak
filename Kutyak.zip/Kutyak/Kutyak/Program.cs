﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Kutyak
{
    class Kutyak
    {
        struct KutyaNevek
        {
            public int Id;
            public string Kutya_Nev;


        }

        struct KutyaFajtak
        {
            public int Kf_Id;
            public string Magyar_Nev;
            public string Eredeti_Nev;
        }

        struct Kutya
        {
            public int Kutya_Id;
            public int Fajta_Id;
            public int Nev_Id;
            public int Eletkor;
            public string U_vizsg;
        }



        static void Main(string[] args)
        {
            List<KutyaNevek> Nev = new List<KutyaNevek>();
            KutyaNevek adat_nev = new KutyaNevek();
            string[] darabol;
            StreamReader sr = new StreamReader(@"D:\forras\KutyaNevek.csv");
            sr.ReadLine();
            while (!sr.EndOfStream)
            {
                darabol = sr.ReadLine().Split(';');
                adat_nev.Id = Convert.ToInt32(darabol[0]);
                adat_nev.Kutya_Nev = darabol[1];
                Nev.Add(adat_nev);
            }
            sr.Close();
           

            List<KutyaFajtak> Fajta = new List<KutyaFajtak>();
            KutyaFajtak adat_fajta = new KutyaFajtak();
           
            StreamReader sr_1 = new StreamReader(@"D:\forras\KutyaFajtak.csv");
            sr_1.ReadLine();
            while (!sr_1.EndOfStream)
            {
                darabol = sr_1.ReadLine().Split(';');
                adat_fajta.Kf_Id = Convert.ToInt32(darabol[0]);
                adat_fajta.Magyar_Nev = darabol[1];
                adat_fajta.Eredeti_Nev = darabol[2];
                Fajta.Add(adat_fajta);
            }
            sr_1.Close();

            List<Kutya> Kutya_Data = new List<Kutya>();
            Kutya adat_kutya = new Kutya();

            StreamReader sr_2 = new StreamReader(@"D:\forras\Kutyak.csv");
            sr_2.ReadLine();
            while (!sr_2.EndOfStream)
            {
                darabol = sr_2.ReadLine().Split(';');
                adat_kutya.Kutya_Id = Convert.ToInt32(darabol[0]);
                adat_kutya.Fajta_Id = Convert.ToInt32(darabol[1]);
                adat_kutya.Nev_Id = Convert.ToInt32(darabol[2]);
                adat_kutya.Eletkor = Convert.ToInt32(darabol[3]);
                adat_kutya.U_vizsg = darabol[4];
                Kutya_Data.Add(adat_kutya);
            }
            sr_2.Close();
            Console.WriteLine("3. feladat : Kutyanevek száma: {0}", Nev.Count);
            Console.WriteLine("6.feladat: Kutyák átlagéletkora: {0}",Math.Round(Kutya_Data.Average(x=> x.Eletkor),2));


            int maxkor_sor = Kutya_Data.FindIndex(x => x.Eletkor == Kutya_Data.Max(y => y.Eletkor));
            int max_Nev_Id = Kutya_Data[maxkor_sor].Nev_Id;
            int max_Fajta_Id = Kutya_Data[maxkor_sor].Fajta_Id;
            int max_Nev = Nev.FindIndex(x => x.Id == max_Nev_Id);
            int max_Fajta = Fajta.FindIndex(x => x.Kf_Id == max_Fajta_Id);
            Console.WriteLine("7. Feladat: Legidősebb kutya neve és fajtája: {0}, {1}",Nev[max_Nev].Kutya_Nev,Fajta[max_Fajta].Magyar_Nev);
            int[] vizsg = Kutya_Data.Where(x => x.U_vizsg == "2018.01.10").Select(y => y.Fajta_Id).Distinct().ToArray();
            int[] db = new int[vizsg.Length];
            for (int i = 0; i < vizsg.Length; i++)
            {
                for (int ij = 0; ij < Kutya_Data.Count; ij++)
                {
                    if (Kutya_Data[ij].Fajta_Id==vizsg[i] && Kutya_Data[ij].U_vizsg=="2018.01.10")
                    {
                        db[i]++;
                    }
                }
            }
            Console.WriteLine("8. feladat: Január 10.-én vizsgált kutya fajták: ");
            for (int i = 0; i < vizsg.Length; i++)
            {
                Console.WriteLine("\t{0}: {1} kutya", Fajta[Fajta.FindIndex(x => x.Kf_Id == vizsg[i])].Magyar_Nev,db[i]);
            }


              Console.ReadKey();

        }
    }
}
